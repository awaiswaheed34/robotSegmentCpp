#include <iostream>
#include "segment.h"
#include "robot.h"

using namespace std;

int main()
{
	robot robo;
	robo.addSegment(point2D(12,3),33,5);
	robo.addSegment(point2D(55,3),35,5);
	robo.printRobotSegments();
	robo.resetRobot();
	robo.printRobotSegments();
	robo.addSegment(point2D(55, 5), 90, 12);
	robo.addSegment(point2D(66, 3), 80, 8);
	robo.removeSegment();
	robo.printRobotSegments();
	return 0;
}